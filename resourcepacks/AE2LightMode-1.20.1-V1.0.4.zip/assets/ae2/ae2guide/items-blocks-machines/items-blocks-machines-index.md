---
navigation:
  title: Items, Blocks, and Machines
  position: 50
---

# Items, Blocks, and Machines

A list of stuff in the mod for other pages to link to, and a description of their function.

## Misc. Ingredients and Blocks

<CategoryIndex category="misc ingredients blocks" />

## Network Infrastructure

<CategoryIndex category="network infrastructure" />

## Devices

<CategoryIndex category="devices" />

## Machines

<CategoryIndex category="machines" />

## Tools

<CategoryIndex category="tools" />