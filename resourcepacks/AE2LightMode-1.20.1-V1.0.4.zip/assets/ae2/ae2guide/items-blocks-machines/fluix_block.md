---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Fluix Block
  icon: fluix_block
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_block
---

# The Fluix Block

<BlockImage id="fluix_block" scale="8" />

The storage block for <ItemLink id="fluix_crystal" />. It is also used in the recipes for a few machines.

## Recipe

<RecipeFor id="fluix_block" />
